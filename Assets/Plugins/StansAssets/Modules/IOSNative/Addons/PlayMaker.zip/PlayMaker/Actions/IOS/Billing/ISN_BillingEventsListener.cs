using UnityEngine;
using System.Collections;
using SA.IOSNative.StoreKit;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Init billing. Best practice to do this on appplicaton start")]
	public class ISN_BillingEventsListener : FsmStateAction {




		public FsmEvent InitCompleteEvent;
		public FsmEvent RestoreProductsCompleteEvent;



		public FsmString TransactionProductId;
		public FsmEvent ProductPurchasedEvent;
		public FsmEvent ProductRestoredEvent;
		public FsmEvent PurchaseFailedEvent;
		public FsmEvent PurchaseDeferredEvent;




		public override void OnEnter() {



			PaymentManager.OnTransactionComplete -= OnTransactionComplete;
			PaymentManager.OnRestoreComplete -= OnRestoreComplete;
			PaymentManager.OnStoreKitInitComplete -= OnStoreKitInitComplete;

			PaymentManager.OnTransactionComplete += OnTransactionComplete;
			PaymentManager.OnRestoreComplete += OnRestoreComplete;
			PaymentManager.OnStoreKitInitComplete += OnStoreKitInitComplete;



		}



		public void OnStoreKitInitComplete (SA.Common.Models.Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(InitCompleteEvent);

			}
		}


		public void OnRestoreComplete (SA.Common.Models.Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(RestoreProductsCompleteEvent);
			}
		}

		public void OnTransactionComplete (PurchaseResult res) {
			TransactionProductId.Value = res.ProductIdentifier;

			switch(res.State) {
				case PurchaseState.Purchased:
					Fsm.Event(ProductPurchasedEvent);
					break;
				case PurchaseState.Restored:
					Fsm.Event(ProductRestoredEvent);
					break;
				case PurchaseState.Deferred:
					Fsm.Event(PurchaseDeferredEvent);
					break;
				case PurchaseState.Failed:
					Fsm.Event(PurchaseFailedEvent);
					break;
			}

		}
	}
}

