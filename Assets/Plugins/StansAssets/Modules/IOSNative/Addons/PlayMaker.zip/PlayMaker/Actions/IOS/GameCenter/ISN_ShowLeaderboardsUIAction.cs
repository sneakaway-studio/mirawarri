﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Center")]
	public class ISN_ShowLeaderboardsUIAction : FsmStateAction {

		
		public override void Reset() {
			
		}


		public override void OnEnter() {
			GameCenterManager.ShowLeaderboards();
			Finish();
		}

	}
}

