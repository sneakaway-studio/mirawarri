﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_CancelAllLocalNotifications : FsmStateAction {

		public override void OnEnter() {
			ISN_LocalNotificationsController.Instance.CancelAllLocalNotifications();
			Finish();
		}
	}
}
